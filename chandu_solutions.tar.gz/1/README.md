1. Linux Operating System Required
2. To install awk on on RPM based GNU/Linux, use Yellowdog Updator Modifier yum package manager as follows :
[root]# yum install gawk
After installation, ensure that AWK is accessible via command line.

$ which awk
On executing the above code, you get the following result −
/usr/bin/awk
---------------------------------------
Install it on Debian based GNU/Linux using Advance Package Tool (APT) package manager as follows −

$ sudo apt-get update
$ sudo apt-get install gawk

3. How to Execute :
	cat file | awk -f test.awk
Here file is the test input
test.awk has the logic to remove consecutive duplicates
